#include <stdio.h>
#include <string.h>

// buffer overflow in a helper function
void get_input() {
    char buffer[20];
    printf("Enter your name: ");
    gets(buffer); // Vulnerable: no bounds checking
    printf("Hello, %s!\n", buffer);
}

int main() {
    get_input();
    return 0;
}
