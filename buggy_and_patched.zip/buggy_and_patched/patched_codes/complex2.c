#include <stdio.h>

int main(int argc, char **argv) {
    char str[128];
    // char *secret = "This is a secret!\n"; // Unused variable, can be removed if not needed

    printf("Enter a string: ");
    // Ensure to use %s as the format specifier instead of using 'str' directly
    scanf("%127s", str); // Limit the input to prevent buffer overflow
    
    // printf(str); // Potential format string vulnerability
    printf("%s", str); // Properly using '%s' as a format specifier to safely print the string

    return 0;
}