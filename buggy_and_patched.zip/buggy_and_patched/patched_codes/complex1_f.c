#include <stdio.h>

int main(int argc, char **argv) {
    char str[128];
    // char *secret = "This is a secret!\n"; // Commenting out unused variable

    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

    // Change comparison to check against EOF instead of NULL
    // if (fscanf(file, "%s", str) == NULL) {
    if (fscanf(file, "%127s", str) == EOF) {  // Using "%127s" to avoid buffer overflow
        printf("Error reading from file or file is empty.\n");
        fclose(file);
        return 1;
    }

    // Change to use a format specifier to ensure proper string handling
    // printf(str);
    printf("%s", str); // Using "%s" to safely print the string

    fclose(file);
    return 0;
}