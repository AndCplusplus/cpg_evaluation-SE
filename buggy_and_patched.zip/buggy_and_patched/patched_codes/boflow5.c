#include <stdio.h>

int main(int argc, char* argv[]) {
    char name[64];

    printf("Enter your name: ");
    
    // Original code: Causes buffer overflow if the input exceeds the buffer size.
    // scanf("%s", name);
    
    // Using fgets instead of scanf to prevent buffer overflow.
    // It reads until a newline or EOF, and limits the input to the size of the buffer - 1.
    fgets(name, sizeof(name), stdin);
    
    // Remove trailing newline character if present
    name[strcspn(name, "\n")] = '\0'; // Replace newline character with null terminator

    printf("Welcome, %s!", name);
    return 0;
}