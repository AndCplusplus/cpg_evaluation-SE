#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int isAdmin;
    char feedback[32];
    char username[32];
} UserProfile;

void processData(char *name, char *comment) {
    UserProfile profile;
    char feedbackMessage[128];

    profile.isAdmin = 0; // By default, user is not an admin

    // Original line - potential buffer overflow
    // strcpy(profile.username, name);
    // Changed to strncpy to prevent buffer overflow
    strncpy(profile.username, name, sizeof(profile.username) - 1); 
    profile.username[sizeof(profile.username) - 1] = '\0'; // Null-terminate to prevent overflow

    // Original line - potential buffer overflow
    // strcpy(profile.feedback, comment); 
    // Changed to strncpy to prevent buffer overflow
    strncpy(profile.feedback, comment, sizeof(profile.feedback) - 1); 
    profile.feedback[sizeof(profile.feedback) - 1] = '\0'; // Null-terminate to prevent overflow

    // Using safe concatenation
    strcpy(feedbackMessage, "Feedback:");
    // Original line potentially vulnerable to buffer overflow
    // strncat(feedbackMessage, profile.feedback, sizeof(feedbackMessage) - strlen(feedbackMessage) - 1); 
    // Change: Ensuring we don't exceed feedbackMessage size when concatenating
    strncat(feedbackMessage, profile.feedback, sizeof(feedbackMessage) - strlen(feedbackMessage) - 1); 

    // Using printf with a format string to prevent format string vulnerability
    // Original line potentially vulnerable
    // printf(feedbackMessage); 
    // Change: Using format string to ensure no format string vulnerability
    printf("%s\n", feedbackMessage);

    if(profile.isAdmin) {
        printf("You have administrative privileges!\n");
        system("/bin/sh"); // Opens a shell if user is an admin
    } else {
        printf("You are a regular user.\n");
    }
}

int main() {
    char name[48];
    char comment[48];
    clearenv(); // Clear all environment variables

    printf("Enter your name: ");
    fgets(name, sizeof(name), stdin);
    name[strcspn(name, "\n")] = 0; // Remove the newline character if present

    printf("Any comments? ");
    fgets(comment, sizeof(comment), stdin);
    comment[strcspn(comment, "\n")] = 0; // Remove the newline character if present

    processData(name, comment);
    return 0;
}