#include <stdio.h>

int main(int argc, char **argv) {
    char str[128];
    char *secret = "This is a secret!\n";  // Unused variable, can be removed or used properly

    // Prompt the user for input
    printf("Enter a string: ");
    
    // Use %127s to prevent buffer overflow (leave room for null terminator)
    // scanf("%s", str); // original vulnerable line
    scanf("%127s", str); // changed to limit input size to prevent overflow

    // printf(str); // original vulnerable line
    printf("%s", str); // changed to use format string to avoid potential vulnerability

    return 0;
}