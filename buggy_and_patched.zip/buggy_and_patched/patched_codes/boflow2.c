#include <stdio.h>
#include <string.h> // Added to include strcmp declaration

// buffer overflow in main
int main() {
    char password[10];
    printf("Enter the password: ");
    // gets(password); // Vulnerable: no bounds checking
    fgets(password, sizeof(password), stdin); // Changed to fgets for safety

    // Remove the newline character from the input, if present
    password[strcspn(password, "\n")] = '\0'; // Strip newline introduced by fgets

    if (strcmp(password, "secret") == 0) {
        printf("Access granted!\n");
    } else {
        printf("Access denied!\n");
    }
    return 0;
}