#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void process_file(const char *filename) {
    // Change buffer size to correct value. It should match the size of line array.
    char line[50];
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Failed to open file");
        return;
    }

    // Change buffer size to match 'line' array size
    // while (fgets(line, 200, file)) { // Vulnerable: buffer size mismatch
    while (fgets(line, sizeof(line), file)) { // Use sizeof to ensure we don't exceed buffer size
        printf("Read line: %s", line);
    }

    fclose(file);
}

int main() {
    char filename[30];
    printf("Enter filename: ");
    // Change gets to fgets to avoid buffer overflow
    // gets(filename); // Vulnerable: no bounds checking
    fgets(filename, sizeof(filename), stdin); // Safer alternative with bounds checking
    // Remove newline character from fgets
    filename[strcspn(filename, "\n")] = 0; // Remove the newline character added by fgets
    process_file(filename);
    return 0;
}