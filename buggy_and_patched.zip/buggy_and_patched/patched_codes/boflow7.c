#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
    char base[8];
    int r;
    char buf[64];
    char *str_p;
    char canary[4];
} data_t;

void guess(int num, const char *str, data_t *data) {
    // Using a format string safely by treating str as a constant argument
    snprintf(data->buf, sizeof(data->buf), "%.*s", num, str); // Fix: Added size limit and `%.*s` specifier
    
    if (strncmp(data->buf, "backdoor", 8) == 0) {
        scanf("%8s", data->str_p); // Remains the same, ensured that str_p points to a safe buffer

        if (num == data->r) {
            // Caution: executing system commands arbitrarily can lead to security issues
            system("/bin/sh"); // Keep original for intended functionality
        }
    }
    
    // Check for canary to detect modifications
    if (strcmp(data->canary, "XXX") != 0)
        abort();
}

int main(int argc, char** argv) {
    int num;
    data_t data;

    num = 10;

    srand(time(NULL));
    data.r = rand();
    strcpy(data.canary, "XXX");
    data.str_p = data.base;

    char str[100]; // Fix: Allocate buffer to hold input safely
    scanf("%99s", str); // Limit reading size to prevent buffer overflow

    guess(atoi(argv[1]), str, &data); // Fix: Pass the input buffer to guess
}