#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

typedef struct {
    int ch;
    int index;
    FILE *f;
    char file_content[64];
} foo;

void open_whatever(char *filename){
    foo p;

    // Open the file
    p.f = fopen(filename,"r");
    if (p.f == NULL){
        puts("The file is missing.");
        exit(1);
    }

    // Initialize the index
    p.index = 0;
    memset(p.file_content, 0, sizeof(p.file_content)); // Initialize the file_content array

    // Put the file in file content until a newline character is found
    while ((p.ch = fgetc(p.f)) != '\n'){
        if (p.ch == EOF || p.index >= sizeof(p.file_content) - 1){ 
            break; 
        }
        p.file_content[p.index] = p.ch;
        p.index++;
    }
    p.file_content[p.index] = '\0';
    fclose(p.f); // close the file

    // Compare the first 4 chars of the file with "flag"
    if (strncmp(p.file_content, "flag", 4) == 0){
        // printf(p.file_content); // Original line vulnerable to format string attack
        printf("%s\n", p.file_content); // Safe alternative, uses format string
    }
}

void write_whatever(char *filename){
    FILE *f = fopen(filename,"w");
    if (f == NULL){
        puts("The file is missing.");
        exit(1);
    }

    printf("Write something to the file: ");

    // Write from stdin to the file until a newline character is found
    // Use a buffer for user input with sufficient limit
    char input[64]; 

    // Check if fgets successfully reads input from stdin
    if (fgets(input, sizeof(input), stdin) != NULL) {
        // Ensure that the input does not exceed the buffer limit
        if (strlen(input) >= sizeof(input) - 1 && input[sizeof(input) - 2] != '\n') {
            // Remove any excessive input in case of overflow
            puts("Input too long, truncating.");
            input[sizeof(input) - 1] = '\0'; // Force null termination
        }
        // Write the safely read input to the file
        fputs(input, f);
    } else {
        puts("No input read, file will not be written");
    }

    fclose(f); // close the file
}

int main(){
    char filename[12] = "file.txt";
    clearenv();
    write_whatever(filename);
    open_whatever(filename);
}